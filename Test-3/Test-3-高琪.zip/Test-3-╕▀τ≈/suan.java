public class suan {
    public static void main(String[] args) {
        int a;
        int b;
        int sum=30;
        for(a=1;a<=30;a++){
            b=30-a;
            if(2*a+4*b==90){
                System.out.println("鸡有"+a+"兔子有"+b );
            }
        }
    }
}
