public class maxn {
    public static void main(String[] args) {
    int n=1;
    int sum=0;
    for(sum=0;sum<=1000;n++){
        sum=sum+n*n;

    }
        System.out.println(n);
    }
}